function controllers(callback) {
    let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            bntAcao = JSON.parse(this.responseText);
            callback(bntAcao);
        }
    };
    xhttp.open("GET", "../controller/controllers.json", true);
    xhttp.send();
}

function preencherHtml(bntAcao) {
    let listaBtncontrollers = "";

    for (let i = 0; i < bntAcao[0].length; i++) {
        const elemento = bntAcao[0];
        listaBtncontrollers += `<a id="${elemento[i].id}" class="bt-controllers"><span>${elemento[i].icone}</span> <span>${elemento[i].nome}</span></a>`;
    }
    document.querySelector("#itens-controllers").innerHTML = listaBtncontrollers;
}

controllers(preencherHtml);

function preencherElementos(bntAcao) {
    let listaElementoscabeca = "";
    let listaElementoscorpo = "";
    let active = "active";

    for (let i = 0; i < bntAcao.length; i++) {
        const elemento = bntAcao[1];
        if(i > 0){
          active = "";
        }
        linhas = "";
        for (let j = 0; j < elemento[i].id.length; j++){
          linhas += `<li><a id="${elemento[i].id[j]}" class="retornacontrol displayflex" data-toggle="modal"><img src="img/${elemento[i].imagem[j]}"></a><span>${elemento[i].item[j]}</span></li>`;
        }

        listaElementoscabeca += `<li role="presentation" class="${active}"><a href="#${elemento[i].nome}" aria-controls="${elemento[i].nome}" role="tab" data-toggle="tab">${elemento[i].nome}</a></li>`;
        listaElementoscorpo += `
          <div role="tabpanel" class="tab-pane ${active}" id="${elemento[i].nome}">
            <ul class="itens-controllers">
              ${linhas}
            </ul>
          </div>`;
    }

    codigoCabeca = `
      <div class="container text-center">
        <ul class="nav nav-tabs embloco" role="tablist">
          ${listaElementoscabeca}
        </ul>
      </div>`;
    codigoCorpo = `
      <div class="tab-content">
          ${listaElementoscorpo}
      </div>`;

    codigoCompleto = codigoCabeca + codigoCorpo;

    document.querySelector("#elementos-controllers").innerHTML = codigoCompleto;
}

controllers(preencherElementos);

/*Controle de elementos*/
$(document).ready(()=> {
  $('.tab').on('click', (event) => {
    $(event.target).parent('.tabs').find('> a.tab.active').removeClass('active');
    $(event.target).addClass('active');
    if(!$(event.target.hash).length) return;
    $('body').stop().animate({
        scrollTop: $(event.target.hash).offset().top - $('#tabs').outerHeight()
    }, 300, 'swing');
  });

})

$(document).on('click', '.retornacontrol', function(){
  id = $(this).attr('id');
  $('#controlerModal').modal({
   show: 'false'
  });
});

